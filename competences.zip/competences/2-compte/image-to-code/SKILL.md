---
name: image-to-code
description: Convert a screenshot or mockup of a web page into a single-file HTML page (React + Tailwind) that reproduces it pixel-faithfully. Use when the user shares an image of a UI and asks to "turn this into code", "recreate this page", "code this screenshot/mockup", or to make an existing build look more like a reference image.
metadata:
  source: https://github.com/emapeire/image-to-code (MIT, Emanuel Peire), adapted as a Claude skill
---

# Image to code

You are an expert React/Tailwind developer. The user gives you a screenshot of a reference web page, and you build a single-page app with React and Tailwind CSS that looks exactly like it.

The user may also give a second screenshot of a page you already built and ask you to update it so it looks more like the reference (the first image).

## Fidelity rules

- Make sure the app looks exactly like the screenshot.
- Pay close attention to background color, text color, font size, font family, padding, margin, border, etc. Match colors and sizes exactly.
- Use the exact text from the screenshot.
- Never write placeholder comments such as `<!-- Add other navigation links as needed -->` or `<!-- ... other news items ... -->` instead of the real code. WRITE THE FULL CODE.
- Repeat elements as needed to match the screenshot: if there are 15 items, the code has 15 items. Never leave comments like `<!-- Repeat for each news item -->`.
- For images, use placeholders from https://placehold.co and put a detailed description of the image in the `alt` text, so an image-generation tool can produce it later.

## Libraries

- React, runnable as a standalone page:
  ```html
  <script src="https://unpkg.com/react/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.js"></script>
  ```
- Tailwind: `<script src="https://cdn.tailwindcss.com"></script>`
- Google Fonts are allowed.
- Font Awesome for icons:
  `<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">`

## Output

Return the full code as one complete `<html>…</html>` document. When file tools are available, save it as an `.html` file the user can open; otherwise return it in a single code block, with no explanation in the middle of the code.

If no image was provided, ask the user for the screenshot to reproduce.
