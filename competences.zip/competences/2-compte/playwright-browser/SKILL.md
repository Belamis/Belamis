---
name: playwright-browser
description: Drive a real headless browser with Playwright (Python) inside the code execution environment. Use when the user asks to open a website, take a screenshot of a page, check how a page renders on desktop or mobile, extract text or links, read console errors, fill a form, click through a flow, or test an HTML page Claude just built.
metadata:
  inspired-by: https://github.com/smartlabsAT/claude-playwright and Anthropic's webapp-testing skill
---

# Playwright browser

Use Playwright for Python to control a headless Chromium browser from the code execution tool.

## 1. Setup (once per conversation)

```bash
python -c "import playwright" 2>/dev/null || pip install playwright
python -m playwright install chromium 2>/dev/null || python -m playwright install --with-deps chromium
```

If a Chromium binary already exists but does not match the Playwright version, pass `--executable-path /path/to/chrome` (or set `CHROMIUM_PATH`) instead of downloading.

If the install fails (no network access in the sandbox), tell the user plainly: browsing needs code execution with network access enabled in Claude's settings. Do not pretend a page was visited.

## 2. Quick actions: `scripts/browse.py`

Run `python scripts/browse.py --help` first. Common uses:

```bash
# Screenshot (desktop, full page)
python scripts/browse.py https://example.com --screenshot out.png --full-page
# Mobile view (390x844, iPhone-like)
python scripts/browse.py https://example.com --mobile --screenshot mobile.png
# Visible text, links, console errors
python scripts/browse.py https://example.com --text --links --console
# A local HTML file built in this conversation
python scripts/browse.py file:///absolute/path/page.html --screenshot page.png --console
```

After a screenshot, look at the image yourself before describing it, and share the file with the user.

## 3. Custom flows

For clicks, forms or multi-step flows, write a short script:

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1280, "height": 800})
    page.goto("https://example.com", wait_until="networkidle")
    page.get_by_role("link", name="More information").click()
    page.wait_for_load_state("networkidle")
    page.screenshot(path="after-click.png", full_page=True)
    browser.close()
```

Rules:
- Prefer role/text locators (`get_by_role`, `get_by_label`, `get_by_text`) over brittle CSS selectors.
- Always wait for `networkidle` (or a specific element) before reading or capturing a dynamic page.
- On failure, take a screenshot and print `page.content()[:2000]` to understand the state before retrying.

## 4. Limits and safety

- The browser runs in Claude's sandbox, not on the user's computer: it cannot reach `localhost` on their machine, nor their logged-in sessions.
- Never enter passwords, payment details or personal data unless the user explicitly provides them for that purpose.
- Respect sites' terms; do not bulk-scrape or bypass logins and captchas.
