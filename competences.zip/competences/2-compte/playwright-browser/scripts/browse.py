#!/usr/bin/env python3
"""Open a URL in headless Chromium and capture a screenshot, text, links or console messages."""
import argparse
import json
import os

from playwright.sync_api import sync_playwright


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("url", help="http(s):// or file:/// URL")
    ap.add_argument("--screenshot", metavar="PATH", help="save a PNG screenshot")
    ap.add_argument("--full-page", action="store_true", help="capture the whole page height")
    ap.add_argument("--mobile", action="store_true", help="390x844 mobile viewport with touch")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=800)
    ap.add_argument("--text", action="store_true", help="print visible body text")
    ap.add_argument("--links", action="store_true", help="print links as JSON")
    ap.add_argument("--console", action="store_true", help="print console messages and page errors")
    ap.add_argument("--executable-path", default=os.environ.get("CHROMIUM_PATH"),
                    help="use an existing Chromium binary (or set CHROMIUM_PATH)")
    ap.add_argument("--timeout", type=int, default=30000, help="navigation timeout in ms")
    args = ap.parse_args()

    messages = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=args.executable_path or None)
        if args.mobile:
            context = browser.new_context(viewport={"width": 390, "height": 844},
                                          device_scale_factor=2, is_mobile=True, has_touch=True)
        else:
            context = browser.new_context(viewport={"width": args.width, "height": args.height})
        page = context.new_page()
        page.on("console", lambda m: messages.append(f"[{m.type}] {m.text}"))
        page.on("pageerror", lambda e: messages.append(f"[pageerror] {e}"))

        response = page.goto(args.url, wait_until="load", timeout=args.timeout)
        try:
            page.wait_for_load_state("networkidle", timeout=5000)
        except Exception:
            pass

        print(f"URL: {page.url}")
        print(f"Status: {response.status if response else 'n/a'}")
        print(f"Title: {page.title()}")

        if args.screenshot:
            page.screenshot(path=args.screenshot, full_page=args.full_page)
            print(f"Screenshot: {args.screenshot}")
        if args.text:
            print("\n--- Text ---")
            print(page.inner_text("body")[:20000])
        if args.links:
            links = page.eval_on_selector_all(
                "a[href]", "els => els.map(a => ({text: a.innerText.trim(), href: a.href}))")
            print("\n--- Links ---")
            print(json.dumps(links, ensure_ascii=False, indent=2))
        if args.console:
            print("\n--- Console ---")
            print("\n".join(messages) or "(none)")

        browser.close()


if __name__ == "__main__":
    main()
